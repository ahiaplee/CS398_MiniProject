A precompiled executable of the project is avaliable in the executable folder
in the event that solution configuration does not match the system's CUDA installation.
